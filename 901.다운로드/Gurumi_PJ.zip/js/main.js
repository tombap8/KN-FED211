// 구르미 갤러리 JS - main.js
